const http = require('http');

// Create an HTTP server
http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Hello World!\n');
}).listen(8080, () => {
    console.log('Server running at http://127.0.0.1:8080');
});
